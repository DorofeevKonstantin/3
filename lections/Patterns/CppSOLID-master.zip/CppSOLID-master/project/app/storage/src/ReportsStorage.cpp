#include "storage/ReportsStorage.hpp"

#include "types/Report.hpp"

namespace storage {
void ReportsStorage::storeReport(const types::Report&)
{
    // TODO: implement storing tax reports, e.g. by using
    // SQL or NoSQL database, persistent in-memory database or just a file
}
} // namespace storage
