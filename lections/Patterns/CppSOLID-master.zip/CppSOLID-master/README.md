![CI](https://github.com/AndriiShostatskyi/CppSOLID/workflows/CI/badge.svg)


# SOLID C++
##### Udemy course https://www.udemy.com/course/solid-cpp/
